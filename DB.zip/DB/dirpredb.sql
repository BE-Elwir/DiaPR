-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Jul 18, 2022 at 05:47 PM
-- Server version: 8.0.18
-- PHP Version: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dirpredb`
--

-- --------------------------------------------------------

--
-- Table structure for table `testingshistory`
--

DROP TABLE IF EXISTS `testingshistory`;
CREATE TABLE IF NOT EXISTS `testingshistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `DateOfBirth` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Gender` int(5) NOT NULL,
  `Weight` int(5) NOT NULL,
  `Height` int(5) NOT NULL,
  `HighCol` int(5) NOT NULL,
  `HighBP` int(5) NOT NULL,
  `Stroke` int(5) NOT NULL,
  `HeartDiseaseorAttack` int(5) NOT NULL,
  `GenHlth` int(5) NOT NULL,
  `MentHlth` int(5) NOT NULL,
  `PhysHlth` int(5) NOT NULL,
  `DiffWalk` int(5) NOT NULL,
  `Fruits` int(5) NOT NULL,
  `Veggies` int(5) NOT NULL,
  `PhysActivity` int(5) NOT NULL,
  `Smoker` int(5) NOT NULL,
  `HvyAlcoholConsump` int(5) NOT NULL,
  `CreatedAt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TestResult` int(5) NOT NULL,
  `CreatedBy` int(5) NOT NULL,
  `Age` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `testingshistory`
--

INSERT INTO `testingshistory` (`id`, `Name`, `DateOfBirth`, `Gender`, `Weight`, `Height`, `HighCol`, `HighBP`, `Stroke`, `HeartDiseaseorAttack`, `GenHlth`, `MentHlth`, `PhysHlth`, `DiffWalk`, `Fruits`, `Veggies`, `PhysActivity`, `Smoker`, `HvyAlcoholConsump`, `CreatedAt`, `TestResult`, `CreatedBy`, `Age`) VALUES
(3, 'maen', '7/6/1994', 0, 70, 175, 10, 1, 1, 0, 3, 2, 4, 0, 1, 0, 0, 0, 1, 'Tue Jul 05 2022', 0, 0, 27),
(4, 'maen', '7/20/1994', 0, 88, 175, 10, 1, 1, 0, 2, 6, 2, 0, 0, 1, 1, 0, 1, 'Tue Jul 05 2022', 0, 0, 27),
(5, 'maen', '7/27/1993', 0, 88, 175, 1, 1, 0, 0, 5, 2, 5, 0, 1, 1, 0, 1, 0, 'Tue Jul 05 2022', 0, 0, 28),
(6, 'maen', '7/27/1950', 0, 110, 155, 10, 1, 0, 1, 5, 8, 10, 0, 0, 1, 1, 0, 1, 'Tue Jul 05 2022', 0, 0, 71),
(7, 'maen', '7/26/1930', 0, 105, 155, 1, 1, 1, 1, 5, 6, 8, 1, 0, 1, 1, 1, 0, 'Tue Jul 05 2022', 0, 0, 91),
(8, 'maen', '7/21/1930', 0, 105, 175, 10, 1, 1, 1, 4, 6, 16, 0, 0, 1, 1, 1, 0, 'Tue Jul 05 2022', 0, 0, 91),
(9, 'maen', '7/13/1930', 0, 108, 175, 1, 0, 1, 1, 2, 11, 11, 0, 0, 0, 1, 1, 1, 'Tue Jul 05 2022', 0, 0, 91),
(10, 'maen', '7/13/1975', 0, 99, 175, 1, 0, 1, 1, 5, 17, 12, 0, 0, 0, 1, 0, 0, 'Tue Jul 05 2022', 0, 0, 46),
(11, 'maen', '7/6/1960', 0, 105, 175, 1, 0, 1, 0, 5, 14, 7, 0, 1, 1, 0, 0, 1, 'Tue Jul 05 2022', 0, 0, 61),
(12, 'test01', '7/13/1955', 0, 105, 172, 10, 1, 1, 1, 5, 8, 7, 0, 1, 0, 0, 1, 0, 'Tue Jul 05 2022', 0, 0, 66),
(13, 'maen', '7/5/1994', 0, 71, 175, 10, 0, 0, 0, 2, 3, 2, 0, 1, 1, 1, 0, 0, 'Tue Jul 05 2022', 0, 0, 28);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
