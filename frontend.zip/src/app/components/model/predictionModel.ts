export  class predictionModel {
    public name:string;
    public dateOfBirth:string;
    public age:number;

    public gender:number;
    public weight:number;
    public height:number;
    public highCol:number;
    public highBP:number;
    public stroke:number;
    public heartDiseaseorAttack:number;
    public genHlth:number;
    public mentHlth:number;
    public physHlth:number;
    public diffWalk:number;
    public fruits:number;
    public veggies:number;
    public physActivity:number;
    public smoker:number;
    public hvyAlcoholConsump:number;
    public createdAt:string;
    public createdBy:string;
}