import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';
import { predictionModel } from '../../model/predictionModel';
import { CoreService } from '../../../services/core.service';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'app-prediction-steps',
  templateUrl: './prediction-steps.component.html',
  styleUrls: ['./prediction-steps.component.scss']
})
export class PredictionStepsComponent implements OnInit {
  public arrayThirty:any; 
  public predictionData: predictionModel= new predictionModel();
  public PredictionResult:boolean;

  personalInformationFormGroup = this._formBuilder.group({
    userName: ['', Validators.required],
    dateOfBirth: ['', Validators.required],
    gender: ['', Validators.required]


  });
  BMIFormGroup = this._formBuilder.group({
    height: ['', Validators.required],
    weight: ['', Validators.required],
  });
  chronicDiseasesFormGroup = this._formBuilder.group({
    HighCol: ['', Validators.required],
    HighBP: ['', Validators.required],
    Stroke: ['', Validators.required],
    HeartDiseaseorAttack: ['', Validators.required],
  
  });
  generalHealthFormGroup = this._formBuilder.group({
    GenHlth: ['', Validators.required],
    MentHlth: ['', Validators.required],
    PhysHlth: ['', Validators.required],
    DiffWalk: ['', Validators.required],
 
  });
  healthyHabitsFormGroup = this._formBuilder.group({
    Fruits: ['', Validators.required],
    Veggies: ['', Validators.required],
    PhysActivity: ['', Validators.required]
    
    
  });
  unHealthyHabitsFormGroup = this._formBuilder.group({
    Smoker: ['', Validators.required],
   
    HvyAlcoholConsump:['', Validators.required],
  });
  isEditable = false;

  constructor(private _formBuilder: FormBuilder, private _coreService: CoreService) {
    
    this.arrayThirty =this.range(1, 30);
  }
  ngOnInit(): void {
  }
    range(start, end) {
    var foo = [];
    for (var i = start; i <= end; i++) {
        foo.push(i);
    }
    return foo;
}
checkDate(){
  var date01 = this.personalInformationFormGroup.controls['dateOfBirth'].value;
  let timeDiff = Math.abs(Date.now() -date01.getTime());
let age = Math.floor((timeDiff / (1000 * 3600 * 24))/365.25);
console.log(age)


  
}

CreatePrediction(){

var dateInsert = this.setModelValues();
//check prediction
var heightM= dateInsert.height/100;
let BMI= dateInsert.weight/(heightM*heightM);
 if(dateInsert.age >55 && BMI >30 && dateInsert.physHlth>=6 && dateInsert.mentHlth>=6 && dateInsert.genHlth >=4){
    this.PredictionResult= true;
  }else{
    this.PredictionResult= false;
  }

 console.log(dateInsert);
 this._coreService.addPridictionHistpry(dateInsert).subscribe(
   data=>{
  console.log("Success");
 },
error=>{
  console.log("error");
}
 
 );
}
setModelValues(){
this.predictionData.name = this.personalInformationFormGroup.controls['userName'].value;
var date01 = this.personalInformationFormGroup.controls['dateOfBirth'].value.toLocaleString();
this.predictionData.dateOfBirth =date01.split(",")[0];
var date02 = this.personalInformationFormGroup.controls['dateOfBirth'].value;
let timeDiff = Math.abs(Date.now() -date02.getTime());
let age = Math.floor((timeDiff / (1000 * 3600 * 24))/365.25);
this.predictionData.age=age;
this.predictionData.gender = this.personalInformationFormGroup.controls['gender'].value;
this.predictionData.height = this.BMIFormGroup.controls['height'].value;
this.predictionData.weight = this.BMIFormGroup.controls['weight'].value;
this.predictionData.highCol = this.chronicDiseasesFormGroup.controls['HighCol'].value;
this.predictionData.highBP = this.chronicDiseasesFormGroup.controls['HighBP'].value;
this.predictionData.stroke = this.chronicDiseasesFormGroup.controls['Stroke'].value;
this.predictionData.heartDiseaseorAttack = this.chronicDiseasesFormGroup.controls['HeartDiseaseorAttack'].value;
this.predictionData.genHlth = this.generalHealthFormGroup.controls['GenHlth'].value;
this.predictionData.mentHlth = this.generalHealthFormGroup.controls['MentHlth'].value;
this.predictionData.physHlth = this.generalHealthFormGroup.controls['PhysHlth'].value;
this.predictionData.diffWalk = this.generalHealthFormGroup.controls['DiffWalk'].value;
this.predictionData.fruits = this.healthyHabitsFormGroup.controls['Fruits'].value;
this.predictionData.veggies = this.healthyHabitsFormGroup.controls['Veggies'].value;
this.predictionData.physActivity = this.healthyHabitsFormGroup.controls['PhysActivity'].value;
this.predictionData.smoker = this.unHealthyHabitsFormGroup.controls['Smoker'].value;
this.predictionData.hvyAlcoholConsump = this.unHealthyHabitsFormGroup.controls['HvyAlcoholConsump'].value;
 return this.predictionData;

}
}


