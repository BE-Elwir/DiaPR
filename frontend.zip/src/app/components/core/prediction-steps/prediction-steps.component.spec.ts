import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PredictionStepsComponent } from './prediction-steps.component';

describe('PredictionStepsComponent', () => {
  let component: PredictionStepsComponent;
  let fixture: ComponentFixture<PredictionStepsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PredictionStepsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PredictionStepsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
