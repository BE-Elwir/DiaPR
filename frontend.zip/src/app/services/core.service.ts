
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { predictionModel } from '../components/model/predictionModel';

@Injectable({
  providedIn: 'root'
})

export class CoreService {
  urlBase = 'http://localhost:3000/api/testPrediction';
  constructor(private http: HttpClient) { }

  /* createServiceProvider(data): Observable<any> {
     return this.http.post('http://alrazii.com/testing/servicesProviders', data);
   }
  
   serviceProviderSignIn(data): Observable<any> {
     return this.http.post('http://alrazii.com/testing/servicesProviders/signin', data);
   }
  getPractitioners(): Observable<any> {
    return this.http.get(this.urlBase + `/search/practitioners?page=1`);
  }*/

  addPridictionHistpry(data) {
    return this.http.post(this.urlBase + `/addHistory`, data);

  }
  getPridictionHistpryData(): Observable<any> {
    return this.http.get(this.urlBase + `/getAlll`);
  }
}
