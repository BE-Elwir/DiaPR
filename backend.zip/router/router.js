const express = require('express') ;
const router = express.Router() ;
const bcrypt = require('bcryptjs') ;
const uuid = require('uuid') ;
const jwt = require('jsonwebtoken') ;
const testPredictionController = require('../controller/testPredictionController.js');


router.get('/testPrediction/getAlll', testPredictionController.getAllHistoryPred); 
router.get('/testPrediction/getOneHistory/:id',testPredictionController.getOneUser)
router.post('/testPrediction/addHistory',testPredictionController.inserOne)

 

module.exports = router;