const express= require('express');
const bodyparser= require('body-parser');
const cors = require('cors');
const mysql =require('mysql2');
const router= require('./router/router.js');
const app =express();
app.use(cors());

//app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());

//app.use(express.json());

app.use('/api', router);

//database connection 
/*const db = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'crudnode',
    port:3308

});

//check database connection
db.connect(err=>{
    if(err){console.log(err,"err");}
    console.log("database connection.....");
});*/

//get all data
/*
app.get('/user',(req,res)=>{
    let qr ='select * from user';
    db.query(qr,(err,result)=>{
        if(err){
            console.log(err,"errs");
        }
        if(result.length >0){
            res.send({
                message:"all users",
                data:result
            });
        }
    });

});

//get one item

app.get('/user/:id',(req,res)=>{

    let gId = req.params.id;
    let qr=`select * from user where id =${gId}`;
    db.query(qr,(err,result)=>{
      if(err){
          console.log(err,"errs");

      }
      if(result.length >0){
          res.send({
              message:'get user',
              data:result

          });
      }else{
          res.send({
              message:"no data found"
          })
      }
    });

});
//post data
app.post('/user',(req,res)=>{
    let name= req.body.fullname;
    let email= req.body.email;
    let mobile= req.body.mobile;
    
    let qr= `insert into user (fullname,email,mobile) values('${name}','${email}','${mobile}')`;
    db.query(qr,(err,result)=>{
        if(err){
            console.log(err,"errs");
        }
        res.send({
            message:'data inserted'
        })
    })
});
//put data
app.put('/user/:id',(req,res)=>{
    let gId= req.params.id;
    let name= req.body.fullname;
    let email= req.body.email;
    let mobile= req.body.mobile;
    
    let qr= `update  user set fullname ='${name}', email='${email}' ,mobile ='${mobile}' where id= ${gId}`;
    db.query(qr,(err,result)=>{
        if(err){
            console.log(err,"errs");
        }
        res.send({
            message:'data updated'
        })
    })
});
//delete data
app.delete('/user/:id',(req,res)=>{
  let gID= req.params.id;
  let qr=`delete from user where id = '${gID}'`;
  db.query(qr,(err,result)=>{
      if(err){
          console.log(err,"errs");
      }
      res.send({
          message:"item deleted"
      })
  });

});
*/

app.listen(3000,()=>{
console.log("server runinng...");
});