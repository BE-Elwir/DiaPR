
const express = require('express');
const bodyparser = require('body-parser');
const router = express.Router();
const db = require('../lib/db.js');
const cors = require('cors');
const mysql = require('mysql2');
const app = express();
app.use(cors());
app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());
const userModule = require('./module.js');

var sqlQuery = 'select * from user';








async function getAllHistoryPred(req, res, next) {
    console.log("sequentialQueries")
    try {
        const result1 = await userModule.SelectAllElements();
        console.log(result1);
        // res.send('id: ' + result1[0]);
        res.send({
            message: "all users",
            data: result1
        })
        next();

        // here you can do something with the three results

    } catch (error) {
        console.log(error)
    }
}

async function inserOne(req, res, next) {

    try {
        const result1 = await userModule.insertUserTestPrediction(req, res);
        console.log(result1);
        // res.send('id: ' + result1[0]);
        res.send({
            message: "all users",
            data: res
        })
        next();

        // here you can do something with the three results

    } catch (error) {
        console.log(error)
    }
}
async function getOneUser(req, res, next) {
    try {
        const result = await userModule.SelectOneUser(req, res);
        console.log("result ONE ", result);
        if (result.length > 0) {
            res.send({
                message: "one user",
                data: result
            })
        } else {
            res.send({
                message: "no user",

            })
        }

        next();

        // here you can do something with the three results

    } catch (error) {
        console.log(error)
    }
}
module.exports = {


    getOneUser,
    getAllHistoryPred,
    inserOne
}