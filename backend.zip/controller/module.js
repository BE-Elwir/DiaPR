const express = require('express') ;
const router = express.Router() ;
const db = require('../lib/db.js') ;
const cors = require('cors');
const mysql =require('mysql2');
const app =express();
app.use(cors());
const bodyparser= require('body-parser');

app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());
var debug = require('debug')('app')

var sqlQuery = 'select * from user';

function get_info() {
    console.log("getAllData22");
        var ret;
    
        db.query(sqlQuery,  (err, rows, fields) =>{
            if (err) {
                // You must `return` in this branch to avoid using callback twice.
                return callback(err);
            }
    
            // Do something with `rows` and `fields` and assign a value to ret.
    
            return  callback(null, ret);
        });
    
   
}

function testQureyResult (req, res, next) {
    console.log("testQureyResult00");
 //   console.log('Trying to find details for page: ' + url.parse(req.url).pathname);
    db.query(sqlQuery, function(err, result) {
        res= result;
        console.log("res",res);
        res.send('id: ' + res);
        next();
    });
};
function myQuery(){ 
    return new Promise(function(resolve, reject){
        var array = new Array();
        const sql1 = "select * from user";
        db.query(sql1, function (err, result, fields) {
            if (err) throw err;
            array = [];
            for(var i=0; i<result.length; i++) {
                array.push(result[i].active);                        
            }
            console.log(array) //here it prints out the array with its values
            resolve(array);
        });
    })
}

const getData = async ()=> {
    var array= await myQuery();
    return array;       
}

app.get((req,res)=>{
     
    let qr ='select * from user';
    db.query(qr,(err,result)=>{
        if(err){
            console.log(err,"errs");
        }
        if(result.length >0){
             
          res.send({
                message:"all users2",
                data:result
            }); 
        }
    });

});

  const getUsers = async () =>{
    try {

        const users = await db.query("select * from user")
await db.end()
console.log("users",users);
return users

      
    } catch (error) {
        
    }
}


SelectAllElements = () =>{
    return new Promise((resolve, reject)=>{
        db.query('SELECT * FROM testingshistory ',  (error, elements)=>{
            if(error){
                return reject(error);
            }
            return resolve(elements);
        });
    });
};

insertUserTestPrediction = (req,res) =>{
    let name= req.body.name;
    let dateOfBirth= req.body.dateOfBirth;
    let age= req.body.age;
    let gender= req.body.gender;
    let weight= req.body.weight;
    let height= req.body.height;
    let highCol= req.body.highCol;
    let highBP= req.body.highBP;
    let stroke= req.body.stroke;
    let heartDiseaseorAttack= req.body.heartDiseaseorAttack;
    let genHlth= req.body.genHlth;
    let mentHlth= req.body.mentHlth;
    let physHlth= req.body.physHlth;
    let diffWalk= req.body.diffWalk;
    let fruits= req.body.fruits;
    let veggies= req.body.veggies;
    let physActivity= req.body.physActivity;
    let smoker= req.body.smoker;
    let hvyAlcoholConsump= req.body.hvyAlcoholConsump;
    let createdAt= new Date().toDateString();
    let createdBy= "test user";
    let qr= `insert into testingshistory (Name,DateOfBirth,Age,Gender,Weight,Height,HighCol,HighBP,Stroke,HeartDiseaseorAttack,
        GenHlth,MentHlth,PhysHlth,DiffWalk,Fruits,Veggies,PhysActivity,Smoker,HvyAlcoholConsump,CreatedAt,CreatedBy)
         values('${name}','${dateOfBirth}','${age}','${gender}','${weight}','${height}','${highCol}','${highBP}','${stroke}'
         ,'${heartDiseaseorAttack}','${genHlth}','${mentHlth}','${physHlth}','${diffWalk}','${fruits}','${veggies}','${physActivity}','${smoker}'
         ,'${hvyAlcoholConsump}','${createdAt}','${createdBy}')`;
    return new Promise((resolve, reject)=>{
        db.query(qr,  (error, elements)=>{
            if(error){
                console.log(err,"errs");
            }
            res.send({
                message:'data inserted'
            })
            
        });
    });
};

SelectOneUser = (req,res) =>{
    let gId = req.params.id;
    let qr=`select * from user where id =${gId}`;
    return new Promise((resolve, reject)=>{
        db.query(qr,  (error, element)=>{
            if(error){
                return reject(error);
            }
            return resolve(element);
        });
    });
};
module.exports={
    get_info,
    testQureyResult,
    getData ,
   
    getUsers,
    SelectAllElements,
    insertUserTestPrediction,
    SelectOneUser


};