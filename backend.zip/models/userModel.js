class UserM {

    constructor(id, fullname,email,mobile) {
      this.fullname = fullname;
      this.email = email;
      this.mobile = mobile;
    }
    
  }

  /*app.post('/signup', async(req, res, next) => {
    try {
      const { email, firstName } = req.body
      const user = new User({ email, firstName })
      const ret = await user.save()
      res.json(ret)
    } catch (error) {
      // Passes errors into the error handler
      return next(error)
    }
  })*/

  //https://buildcoding.com/javascript-create-model-class-with-getters-setters/
  //https://medium.com/@luke_smaki/javascript-es6-classes-8a34b0a6720a